#!/bin/sh
# ZAPRET2 FULL CIRCULAR ladder — 2609 + 2709 evidence package
# User-requested broad ladder, intentionally NOT HAP-validated.
# HTTP: ME -> HC -> HF
# TLS:  TS -> TF -> TC
# QUIC: QF -> QI
# This replaces ONLY the Strategy27 exact ME/HC/TS/QF profiles in NFQWS2_OPT
# with 3 L7 circular profiles. The existing NFQWS2_OPT fallback body is preserved.
# No DNS/routing/VPN/PBR/QNUM/MODE_FILTER changes.
set -eu
BASE=/etc/zapret2/strategy27
CFG=/opt/zapret2/config
D=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_CFG="/opt/zapret2/config.strategy27-full-circular-pre-$STAMP"
TMP="/tmp/zapret2-full-circular-$STAMP"
[ -f "$CFG" ] || { echo "INSTALL_FAILED: missing $CFG" >&2; exit 1; }
for f in strategy27-http-circular-all.txt strategy27-tls-circular-all.txt strategy27-quic-circular-all.txt; do
  [ -f "$D/$f" ] || { echo "INSTALL_FAILED: missing $D/$f" >&2; exit 1; }
done
cp -a "$CFG" "$BACKUP_CFG"
mkdir -p "$BASE"
cp -f "$D/strategy27-http-circular-all.txt" "$BASE/strategy27-http-circular-all.txt"
cp -f "$D/strategy27-tls-circular-all.txt" "$BASE/strategy27-tls-circular-all.txt"
cp -f "$D/strategy27-quic-circular-all.txt" "$BASE/strategy27-quic-circular-all.txt"
# Replace only the four Strategy27 exact-profile lines. Existing fallback stays verbatim.
awk '
BEGIN{skip=0; inserted=0}
/^--filter-tcp=80 --filter-l7=http --hostlist=\/etc\/zapret2\/strategy27\/strategy27-me.txt/ { if(!inserted){print "--filter-tcp=80 --filter-l7=http --hostlist=/etc/zapret2/strategy27/strategy27-http-circular-all.txt --payload=http_req --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=http_methodeol:strategy=1 --lua-desync=http_hostcase:strategy=2 --lua-desync=fake:blob=fake_default_http:tcp_ts=-1000:strategy=3:final --new"; inserted=1}; next }
/^--filter-tcp=80 --filter-l7=http --hostlist=\/etc\/zapret2\/strategy27\/strategy27-hc.txt/ { next }
/^--filter-tcp=443 --filter-l7=tls --hostlist=\/etc\/zapret2\/strategy27\/strategy27-ts.txt/ { if(!inserted2){print "--filter-tcp=443 --filter-l7=tls --hostlist=/etc/zapret2/strategy27/strategy27-tls-circular-all.txt --payload=tls_client_hello --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=tcpseg:pos=0,-1:seqovl=1:strategy=1 --lua-desync=drop:strategy=1 --lua-desync=fake:blob=fake_default_tls:tcp_ts=-1000:strategy=2 --lua-desync=fake:blob=0x00000000:tcp_md5:repeats=1:strategy=3 --lua-desync=fake:blob=fake_default_tls:tcp_md5:tls_mod=rnd,dupsid:repeats=1:strategy=3 --lua-desync=multisplit:pos=2:strategy=3:final --new"; inserted2=1}; next }
/^--filter-udp=443 --filter-l7=quic --hostlist=\/etc\/zapret2\/strategy27\/strategy27-qf.txt/ { if(!inserted3){print "--filter-udp=443 --filter-l7=quic --hostlist=/etc/zapret2/strategy27/strategy27-quic-circular-all.txt --payload=quic_initial --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=fake:blob=fake_default_quic:repeats=11:strategy=1 --lua-desync=send:ipfrag:strategy=2 --lua-desync=drop:strategy=2:final"; inserted3=1}; next }
{print}
END{ if(!inserted || !inserted2 || !inserted3) exit 2 }
' "$CFG" > "$TMP" || { echo "INSTALL_FAILED: strategy27 exact profile anchors not found" >&2; rm -f "$TMP"; exit 2; }
cp -f "$TMP" "$CFG"
rm -f "$TMP"
echo "INSTALL=SUCCESS"
echo "BACKUP_CONFIG=$BACKUP_CFG"
echo "HTTP_DOMAINS=$(wc -l < "$D/strategy27-http-circular-all.txt")"
echo "TLS_DOMAINS=$(wc -l < "$D/strategy27-tls-circular-all.txt")"
echo "QUIC_DOMAINS=$(wc -l < "$D/strategy27-quic-circular-all.txt")"
echo "LADDERS=HTTP:ME>HC>HF TLS:TS>TF>TC QUIC:QF>QI"
echo "RUNTIME_TEST=NOT_PERFORMED"
