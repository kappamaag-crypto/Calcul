# ZAPRET2 FULL CIRCULAR — 2609 + 2709

## Requested configuration

HTTP: **ME → HC → HF**
TLS: **TS → TF → TC**
QUIC: **QF → QI**

This is the broad circular configuration requested by the user. It is **not HAP-validated**.

## Evidence-derived hostlists

- ME: 44 explicit-FOUND domains
- HC: 159 explicit-FOUND domains
- TS: 194 explicit-FOUND domains
- TF: 15 explicit-FOUND domains
- TC: 2 explicit-FOUND domains
- QF: 111 explicit-FOUND domains
- QI: 2 explicit-FOUND domains
- HF: 149 candidate domains with successful AVAILABLE evidence; **0 explicit FOUND**

Unified circular hostlists:
- HTTP: 203 domains (ME ∪ HC ∪ HF)
- TLS: 195 domains (TS ∪ TF ∪ TC)
- QUIC: 113 domains (QF ∪ QI)

## Circular semantics

Each profile starts with strategy 1. On detected failure it rotates to strategy 2, then strategy 3 where present. The final strategy is marked `final`.

HTTP:
1. ME `http_methodeol`
2. HC `http_hostcase`
3. HF `fake_default_http + tcp_ts=-1000` (candidate-only evidence)

TLS:
1. TS `tcpseg + drop`
2. TF `fake_default_tls + tcp_ts=-1000`
3. TC exact TLS1.2 special sequence

QUIC:
1. QF `fake_default_quic:repeats=11`
2. QI `send:ipfrag + drop` (final)

## Important evidence boundary

Only the source logs establish FOUND. They do not establish universal success on HAP. HF is deliberately included because the user requested the full ladder, but its evidence status remains candidate-only.

## Installation

Upload this directory to HAP and run:

```sh
cd /path/to/ZAPRET2_FULL_CIRCULAR_READY_2609_2709
sh install-strategy27-full-circular.sh
/etc/init.d/zapret2 restart
```

The installer backs up `/opt/zapret2/config`, installs the 3 circular hostlists, and replaces only the Strategy27 ME/HC/TS/QF profile block inside `NFQWS2_OPT`. The existing fallback body after the Strategy27 block is preserved.

No DNS, routing, VPN, PBR, QNUM or MODE_FILTER changes are made.
No runtime site/service test is performed.
