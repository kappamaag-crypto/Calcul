# ZAPRET2 DEEP STRATEGY MATRIX — 2609 + 2709

**Purpose:** derive the deepest domain-specific fallback ladders supported by the two supplied raw blockcheck logs, without hAP runtime testing.

## Candidate signatures present in both raw runs

| ID | L7 | Exact signature | Evidence disposition |
|---|---|---|---|
| ME | HTTP | `--payload=http_req --lua-desync=http_methodeol` | EXPLICIT FOUND |
| HC | HTTP | `--payload=http_req --lua-desync=http_hostcase` | EXPLICIT FOUND |
| HF | HTTP | `--payload=http_req --lua-desync=fake:blob=fake_default_http:tcp_ts=-1000` | CANDIDATE ONLY — 0 explicit FOUND |
| TS | TLS | `--payload=tls_client_hello --lua-desync=tcpseg:pos=0,-1:seqovl=1 --lua-desync=drop` | EXPLICIT FOUND |
| TF | TLS | `--payload=tls_client_hello --lua-desync=fake:blob=fake_default_tls:tcp_ts=-1000` | EXPLICIT FOUND |
| TC | TLS | `--payload=tls_client_hello --lua-desync=fake:blob=0x00000000:tcp_md5:repeats=1 --lua-desync=fake:blob=fake_default_tls:tcp_md5:tls_mod=rnd,dupsid:repeats=1 --lua-desync=multisplit:pos=2` | EXPLICIT FOUND |
| QF | QUIC | `--payload=quic_initial --lua-desync=fake:blob=fake_default_quic:repeats=11` | EXPLICIT FOUND |
| QI | QUIC | `--payload=quic_initial --lua-desync=send:ipfrag --lua-desync=drop` | EXPLICIT FOUND |
| LX | TLS | `--payload=tls_client_hello --lua-desync=luaexec:code=desync.pat=tls_mod(fake_default_tls,'rnd,rndsni,dupsid,padencap',desync.reasm_data) --lua-desync=tcpseg:pos=0,-1:seqovl=#pat:seqovl_pattern=pat --lua-desync=drop` | TESTED NOT FOUND — 0 AVAILABLE / 0 FOUND |

## Combined evidence counts over 297 unique domains

| Strategy | FOUND | AVAILABLE only | UNAVAILABLE | UNKNOWN/ABORTED |
|---|---:|---:|---:|---:|
| ME | 44 | 155 | 53 | 45 |
| HC | 159 | 0 | 93 | 45 |
| HF | 0 | 148 | 104 | 45 |
| TS | 194 | 1 | 57 | 45 |
| TF | 15 | 0 | 237 | 45 |
| TC | 2 | 0 | 250 | 45 |
| QF | 111 | 0 | 141 | 45 |
| QI | 2 | 68 | 182 | 45 |
| LX | 0 | 0 | 252 | 45 |

## Deepest domain-specific ladders

Ordering is deterministic: HTTP HC→ME→HF; TLS TS→TF→TC; QUIC QF→QI. A strategy is included for a domain only when it was AVAILABLE or EXPLICIT FOUND in at least one of the two runs. `LX` is excluded because it had zero successful candidates.

| L7 | Ladder | Domains |
|---|---|---:|
| HTTP | `HC > ME > HF` | 142 | oaistatic.com, torrents.ru, discordactivities.com, vimeocdn.com, objects.githubusercontent.com, www.xbox.com |
| HTTP | `NONE` | 94 | |
| HTTP | `ME` | 42 | video.twimg.com, api.linkedin.com, www.instagram.com, fbcdn.net, rezka-ua.tv, www.medium.com |
| HTTP | `HC > ME` | 13 | kimi.com, visualstudio.com, outlook.office.com, www.microsoft365.com, nintendo.com, office.com |
| HTTP | `HC > HF` | 4 | dmcdn.net, stability.ai, camo.githubusercontent.com, cohere.com |
| HTTP | `ME > HF` | 2 | googleadservices.com, abs.twimg.com |
| TLS | `TS` | 178 | oaistatic.com, discordactivities.com, objects.githubusercontent.com, www.xbox.com, video.twimg.com, api.linkedin.com |
| TLS | `NONE` | 102 | |
| TLS | `TS > TF` | 15 | claude.ai, onedrive.com, api.perplexity.ai, outlook.office.com, cloudflare-dns.com, www.microsoft365.com |
| TLS | `TS > TC` | 2 | hdrzk.org, media.licdn.com |
| QUIC | `NONE` | 184 | |
| QUIC | `QF > QI` | 68 | oaistatic.com, www.xbox.com, oauth.reddit.com, spotify.com, old.reddit.com, ai.google.dev |
| QUIC | `QF` | 43 | api.linkedin.com, fbcdn.net, www.medium.com, scontent.cdninstagram.com, hdrezka.tv, nnmclub.to |
| QUIC | `QI` | 2 | connect.facebook.net, sharepoint.com |

## Maximum depth

- HTTP: **3** (`HC → ME → HF`) for 142 domains.
- TLS: **2** (`TS → TF`) for 15 domains and **2** (`TS → TC`) for 2 domains; no domain has three successful TLS candidates.
- QUIC: **2** (`QF → QI`) for 68 domains.
- Additional TLS `LX` (`luaexec`) was tested but never AVAILABLE and never FOUND, so it is not a usable fallback.

## Important evidence boundary

`EXPLICIT FOUND` means the raw log emitted `working strategy found`. `AVAILABLE` means the candidate test itself returned AVAILABLE but was not selected as the explicit FOUND result. The deeper backup matrix intentionally uses AVAILABLE evidence as a fallback candidate, because the user requested trying the next strategy when the first fails. This is stronger than blind global stacking, but it is still source-environment evidence, not hAP validation.

## Artifacts

- `ZAPRET2_DEEP_STRATEGY_MATRIX_2609_2709.csv` — 297×9 domain/strategy evidence matrix.
- `ZAPRET2_DEEP_CIRCULAR_GROUPS_2609_2709.csv` — exact domain groups by usable ladder.

## Router-design implication

Do not use one global union hostlist if the goal is evidence-derived deep fallback. Instead, use domain groups by exact ladder pattern so a domain only rotates through strategies that were successful for that domain in 2609 or 2709. This yields 5 HTTP ladder groups, 3 TLS groups, and 3 QUIC groups.

Status: **DONE — deep evidence extraction**. Router unchanged.
