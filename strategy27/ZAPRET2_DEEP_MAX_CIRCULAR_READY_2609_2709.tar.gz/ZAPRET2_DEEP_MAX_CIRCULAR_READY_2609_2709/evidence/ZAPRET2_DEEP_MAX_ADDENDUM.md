# Deep MAX Circular addendum — 2609 + 2709

## Why 3/3/2 is the current maximum

The `circular` mechanism itself has no 3/2/2 ceiling. Its implementation accepts sequential `strategy=1..N`; the only structural constraint is no gaps. Therefore more than three strategies are technically possible.

The ceiling here comes from the supplied raw logs.

Distinct tested signatures in the two logs:

HTTP
- ME: `http_methodeol`
- HC: `http_hostcase`
- HF: `fake_default_http + tcp_ts=-1000`

TLS
- TS: `tcpseg + drop`
- TF: `fake_default_tls + tcp_ts=-1000`
- TC: TLS1.2 special composite
- LX: `luaexec + tls_mod(...) + tcpseg + drop`

QUIC
- QF: `fake_default_quic:repeats=11`
- QI: `send:ipfrag + drop`

No other distinct strategy signature is present in the two supplied raw logs.

## Evidence-backed depth

- HTTP: maximum 3 successful candidates on one domain.
- TLS: maximum 2 successful candidates on one domain.
- QUIC: maximum 2 successful candidates on one domain.

## Max-tested extension

LX is the only additional distinct TLS signature beyond the successful classes. It was tested but produced 0 AVAILABLE / 0 FOUND in both runs. It is therefore appended only as a last-resort experimental step:

- TS -> TF -> LX
- TS -> TC -> LX
- TS -> LX

This means the package's **maximum operational depth** is now 3 for HTTP, 3 for TLS, and 2 for QUIC.

This does not upgrade LX to FOUND and does not claim that LX works on the hAP or on any particular domain.

## How to go beyond this

To obtain a fourth or fifth successful fallback, the blockcheck candidate universe itself must be expanded and rerun. The current two raw logs do not contain additional successful distinct signatures. Importing arbitrary strategies from other configurations would be new external evidence, not evidence from this project.
