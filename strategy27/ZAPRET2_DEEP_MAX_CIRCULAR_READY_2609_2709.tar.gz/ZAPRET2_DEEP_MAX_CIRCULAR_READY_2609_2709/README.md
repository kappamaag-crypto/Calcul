# ZAPRET2 DEEP MAX CIRCULAR READY — 2609 + 2709

## Goal

Use the deepest fallback ladder supported by the two supplied raw blockcheck runs.

The `circular` mechanism itself is not limited to three strategies; it accepts sequential `strategy=1..N` with no gaps. The limit in this package is therefore the strategy diversity actually present in the raw logs.

## Evidence-backed ladder

HTTP:
- HC -> ME -> HF (142 domains)
- HC -> ME (13)
- HC -> HF (4)
- ME -> HF (2)
- ME only (42)

TLS:
- TS -> TF (15)
- TS -> TC (2)
- TS only (178)

QUIC:
- QF -> QI (68)
- QF only (43)
- QI only (2)

## Maximum tested extension

The raw logs contain one additional distinct TLS signature:

`LX = luaexec:code=desync.pat=tls_mod(fake_default_tls,'rnd,rndsni,dupsid,padencap',desync.reasm_data)` followed by generated `tcpseg` and `drop`.

LX had 0 AVAILABLE and 0 EXPLICIT FOUND in the supplied runs. Because the user requested the deepest possible fallback, LX is included as a **final experimental last-resort**, after all evidence-backed TLS strategies:

- TS -> TF -> LX
- TS -> TC -> LX
- TS -> LX

Therefore the package now has:

- HTTP maximum depth: **3**
- TLS maximum operational depth: **3**
- QUIC maximum depth: **2**

Successful/evidence-backed maximum remains HTTP 3 / TLS 2 / QUIC 2.

## Installation safety

The installer:
- stages all hostlists before changing the live tree;
- validates hostlists are one-domain-per-line and sorted/unique;
- strips old Strategy27 exact profiles from the preserved fallback body so they are not duplicated;
- backs up `/opt/zapret2/config` before commit;
- backs up any existing deep-circular directory before replacing it;
- atomically commits the staged config and hostlists;
- automatically restores the pre-install config and previous deep-circular directory on any failure after filesystem modification;
- preserves a failed install directory instead of deleting it;
- does not restart Zapret2;
- does not perform HAP runtime validation;
- does not change MODE_FILTER, QNUM, DNS, routing, VPN, PBR or unrelated firewall settings.

## After upload to hAP

Run only:

```sh
cd /path/to/ZAPRET2_DEEP_MAX_CIRCULAR_READY_2609_2709
sh install-strategy27-deep-max-circular.sh
/etc/init.d/zapret2 restart
```

No application/site runtime test is performed by the installer.

## Important evidence boundary

HF remains candidate-only. LX remains tested-not-found. The package intentionally uses both as last-resort experimental fallbacks because that is the user's requested maximum-depth mode. Neither is presented as universal or hAP-validated.
