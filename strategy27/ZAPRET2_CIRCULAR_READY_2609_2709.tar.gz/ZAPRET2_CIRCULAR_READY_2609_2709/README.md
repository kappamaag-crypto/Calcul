# ZAPRET2 strategy27 — ready-to-upload circular backups

Prepared from the exact `EXPLICIT FOUND` evidence in `blockcheck2609_FULL.log` + `blockcheck2709.log`.

## What is included

- 14 TLS domains with `TS -> TF` backup.
- 2 TLS domains with `TS -> TC` backup.
- Exclusion list for moving those 16 domains out of the ordinary TS-primary hostlist.
- One self-contained installer: `install-strategy27-circular-backups.sh`.

## Deployment model

For each selected host:

`TS primary -> one detected failure -> TF/TC backup -> final`

The ordinary ME/HC/TS/QF architecture and existing autohostlist fallback are preserved. No DNS, routing, VPN, PBR, QNUM or MODE_FILTER changes are made.

## Important

This package is **EVIDENCE-BACKED / NOT_VALIDATED_ON_HAP**. It intentionally does not run HTTPS checks or other runtime tests. The installer creates rollback copies before changing `/opt/zapret2/config` and the TS hostlist.

It assumes the existing OpenWrt Zapret2 datapath already redirects enough incoming TCP reply packets for the current autohostlist/circular machinery. It does not change the existing packet limits.

## Run on hAP

Upload this directory to the router, then run:

```sh
cd /path/to/ZAPRET2_CIRCULAR_READY_2609_2709
./install-strategy27-circular-backups.sh
/etc/init.d/zapret2 restart
```

No test is performed by the installer or by the restart line beyond applying the configuration.

## Exact circular profiles

### TS -> TF

```text
--filter-tcp=443 --filter-l7=tls --hostlist=/etc/zapret2/strategy27/strategy27-ts-circular-tf.txt --payload=tls_client_hello --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=tcpseg:pos=0,-1:seqovl=1:strategy=1 --lua-desync=drop:strategy=1 --lua-desync=fake:blob=fake_default_tls:tcp_ts=-1000:strategy=2:final --new
```

### TS -> TC

```text
--filter-tcp=443 --filter-l7=tls --hostlist=/etc/zapret2/strategy27/strategy27-ts-circular-tc.txt --payload=tls_client_hello --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=tcpseg:pos=0,-1:seqovl=1:strategy=1 --lua-desync=drop:strategy=1 --lua-desync=fake:blob=0x00000000:tcp_md5:repeats=1:strategy=2 --lua-desync=fake:blob=fake_default_tls:tcp_md5:tls_mod=rnd,dupsid:repeats=1:strategy=2 --lua-desync=multisplit:pos=2:strategy=2:final --new
```

The official zapret2 `circular` implementation requires strategy numbers to start at 1 with no gaps; a `final` strategy stops further rotation. citeturn614457view0 The official zapret2 discussion demonstrates `fails=1:retrans=1` for making the second strategy trigger promptly after a detected failure. citeturn551421search1
