# ZAPRET2 DEEP CIRCULAR READY — 2609 + 2709

This is the deeper evidence-conditioned circular design requested by the user.

## Maximum depth found in the two raw logs

- HTTP: up to **3** successful candidates per domain: `HC -> ME -> HF`.
- TLS: up to **2** successful candidates per domain: `TS -> TF` or `TS -> TC`.
- QUIC: up to **2** successful candidates per domain: `QF -> QI`.
- TLS `LX` (`luaexec`) was tested but had **0 AVAILABLE / 0 FOUND**, so it is excluded.

## Exact ladder groups

HTTP:
- HC -> ME -> HF: 142
- HC -> ME: 13
- HC -> HF: 4
- ME -> HF: 2
- ME only: 42

TLS:
- TS -> TF: 15
- TS -> TC: 2
- TS only: 178

QUIC:
- QF -> QI: 68
- QF only: 43
- QI only: 2

## Evidence rule

A strategy is placed in a domain ladder only if the corresponding candidate was AVAILABLE or EXPLICIT FOUND in at least one of the 2609/2709 runs. This is deeper and safer than putting every domain into every strategy globally.

HF is included because it was requested, but remains candidate-only in the evidence classification: 0 explicit FOUND.

## Deployment

The installer backs up `/opt/zapret2/config` and the current TS hostlist, installs evidence-conditioned hostlists and replaces only the Strategy27 exact profile block. It does not change DNS, routing, VPN, PBR, QNUM or MODE_FILTER and performs no runtime validation.

Archive generated locally from the two uploaded raw logs.
