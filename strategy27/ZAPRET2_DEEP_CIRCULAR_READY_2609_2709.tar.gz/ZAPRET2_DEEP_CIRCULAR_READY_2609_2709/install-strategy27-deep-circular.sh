#!/bin/sh
# ZAPRET2 DEEP CIRCULAR installer — generated from blockcheck2609_FULL.log + blockcheck2709.log
# No HAP runtime validation is performed here.
set -eu
BASE=/etc/zapret2/strategy27/deep-circular
CFG=/opt/zapret2/config
SRC_DIR=$(CDPATH= cd -- "$(dirname "$0")" && pwd)
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP_CFG="/opt/zapret2/config.deep-circular-pre-$STAMP"
BACKUP_TS="/etc/zapret2/strategy27/strategy27-ts-pre-deep-circular-$STAMP.txt"
FAIL(){ echo "INSTALL_FAILED: $*" >&2; exit 1; }
[ -f "$CFG" ] || FAIL "missing $CFG"
# Required original strategy27 files
for f in strategy27-me.txt strategy27-hc.txt strategy27-ts.txt strategy27-qf.txt; do [ -f "/etc/zapret2/strategy27/$f" ] || FAIL "missing /etc/zapret2/strategy27/$f"; done
# Make rollback backups
cp -a "$CFG" "$BACKUP_CFG"
cp -a /etc/zapret2/strategy27/strategy27-ts.txt "$BACKUP_TS"
mkdir -p "$BASE"
# Install evidence-conditioned hostlists
for f in "$SRC_DIR"/hostlists/*.txt; do cp -f "$f" "$BASE/"; done
# Extract the current NFQWS2_OPT body while preserving the pre-existing fallback body.
OLDOPT=/tmp/deep-circular-oldopt-$STAMP
NEWCFG=/tmp/deep-circular-config-$STAMP
awk 'BEGIN{inopt=0;found=0}/^NFQWS2_OPT="/{inopt=1;found=1;line=$0;sub(/^NFQWS2_OPT="/,"",line);if(line!=""){if(line ~ /"([[:space:]]*)$/)sub(/"([[:space:]]*)$/,"",line);if(line!="")print line}next}inopt && /^"[[:space:]]*$/{inopt=0;next}inopt{print;next}END{if(!found)exit 2}' "$CFG" > "$OLDOPT" || FAIL "cannot extract NFQWS2_OPT"
# Remove the four existing Strategy27 exact profiles, then insert evidence-conditioned deep-circular profiles.
# The existing autohostlist fallback and unrelated config remain verbatim.
awk -v oldopt="$OLDOPT" '
BEGIN{inopt=0;injected=0}
/^NFQWS2_OPT="/{
 print "NFQWS2_OPT=\""
 print "--filter-tcp=80 --filter-l7=http --hostlist=/etc/zapret2/strategy27/deep-circular/http-hc-me-hf.txt --payload=http_req --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=http_hostcase:strategy=1 --lua-desync=http_methodeol:strategy=2 --lua-desync=fake:blob=fake_default_http:tcp_ts=-1000:strategy=3:final --new"
 print "--filter-tcp=80 --filter-l7=http --hostlist=/etc/zapret2/strategy27/deep-circular/http-hc-me.txt --payload=http_req --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=http_hostcase:strategy=1 --lua-desync=http_methodeol:strategy=2:final --new"
 print "--filter-tcp=80 --filter-l7=http --hostlist=/etc/zapret2/strategy27/deep-circular/http-hc-hf.txt --payload=http_req --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=http_hostcase:strategy=1 --lua-desync=fake:blob=fake_default_http:tcp_ts=-1000:strategy=2:final --new"
 print "--filter-tcp=80 --filter-l7=http --hostlist=/etc/zapret2/strategy27/deep-circular/http-me-hf.txt --payload=http_req --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=http_methodeol:strategy=1 --lua-desync=fake:blob=fake_default_http:tcp_ts=-1000:strategy=2:final --new"
 print "--filter-tcp=80 --filter-l7=http --hostlist=/etc/zapret2/strategy27/deep-circular/http-me.txt --payload=http_req --lua-desync=http_methodeol --new"
 print "--filter-tcp=443 --filter-l7=tls --hostlist=/etc/zapret2/strategy27/deep-circular/tls-ts-tf.txt --payload=tls_client_hello --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=tcpseg:pos=0,-1:seqovl=1:strategy=1 --lua-desync=drop:strategy=1 --lua-desync=fake:blob=fake_default_tls:tcp_ts=-1000:strategy=2:final --new"
 print "--filter-tcp=443 --filter-l7=tls --hostlist=/etc/zapret2/strategy27/deep-circular/tls-ts-tc.txt --payload=tls_client_hello --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=tcpseg:pos=0,-1:seqovl=1:strategy=1 --lua-desync=drop:strategy=1 --lua-desync=fake:blob=0x00000000:tcp_md5:repeats=1:strategy=2 --lua-desync=fake:blob=fake_default_tls:tcp_md5:tls_mod=rnd,dupsid:repeats=1:strategy=2 --lua-desync=multisplit:pos=2:strategy=2:final --new"
 print "--filter-tcp=443 --filter-l7=tls --hostlist=/etc/zapret2/strategy27/deep-circular/tls-ts.txt --payload=tls_client_hello --lua-desync=tcpseg:pos=0,-1:seqovl=1 --lua-desync=drop --new"
 print "--filter-udp=443 --filter-l7=quic --hostlist=/etc/zapret2/strategy27/deep-circular/quic-qf-qi.txt --payload=quic_initial --lua-desync=circular:fails=1:retrans=1:reset --lua-desync=fake:blob=fake_default_quic:repeats=11:strategy=1 --lua-desync=send:ipfrag:strategy=2 --lua-desync=drop:strategy=2:final --new"
 print "--filter-udp=443 --filter-l7=quic --hostlist=/etc/zapret2/strategy27/deep-circular/quic-qf.txt --payload=quic_initial --lua-desync=fake:blob=fake_default_quic:repeats=11 --new"
 print "--filter-udp=443 --filter-l7=quic --hostlist=/etc/zapret2/strategy27/deep-circular/quic-qi.txt --payload=quic_initial --lua-desync=send:ipfrag --lua-desync=drop"
 while((getline line < oldopt)>0)print line;close(oldopt);print "\"";inopt=1;injected=1;next}
inopt && /^"[[:space:]]*$/{inopt=0;next}
inopt{next}{print}
END{if(!injected)exit 3}' "$CFG" > "$NEWCFG" || FAIL "cannot build new config"
cp -f "$NEWCFG" "$CFG"
rm -f "$OLDOPT" "$NEWCFG"
echo "INSTALL=SUCCESS"
echo "BACKUP_CONFIG=$BACKUP_CFG"
echo "BACKUP_TS=$BACKUP_TS"
echo "HTTP_GROUPS=5"
echo "TLS_GROUPS=3"
echo "QUIC_GROUPS=3"
echo "NOTE=NO HAP RUNTIME TEST PERFORMED"
